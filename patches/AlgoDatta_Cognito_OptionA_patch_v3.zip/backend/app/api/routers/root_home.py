from fastapi import APIRouter, Depends
from app.security.roles import require_roles

router = APIRouter()

@router.get("/", tags=["root"])
def root_ok(user = Depends(require_roles("admin","analyst","trader"))):
    return {"status":"ok","role":getattr(user, "role", None)}

@router.get("/healthz", tags=["root"])
def healthz():
    return {"status":"ok"}
