import os, json
from datetime import datetime
from sqlalchemy import select
from app.db.session import SessionLocal
from app.db.models import User  # Ensure this model has: cognito_sub (unique), email, name, role, last_login_at

DEFAULT_ROLE = os.getenv("DEFAULT_ROLE", "trader")
ROLE_EMAIL_MAP = {}
try:
    ROLE_EMAIL_MAP = json.loads(os.getenv("ROLE_EMAIL_MAP", "{}"))
except Exception:
    ROLE_EMAIL_MAP = {}

def _role_for(email: str|None) -> str:
    if not email:
        return DEFAULT_ROLE
    for role, arr in ROLE_EMAIL_MAP.items():
        if isinstance(arr, list) and email.lower() in [a.lower() for a in arr]:
            return role
    return DEFAULT_ROLE

def upsert_from_claims(sub: str, email: str|None, name: str|None):
    with SessionLocal() as db:
        u = db.execute(select(User).where(User.cognito_sub==sub)).scalar_one_or_none()
        if u:
            u.last_login_at = datetime.utcnow()
            if email and u.email != email:
                u.email = email
            if name and getattr(u, "name", None) != name:
                u.name = name
        else:
            u = User(
                cognito_sub=sub,
                email=email,
                name=name,
                role=_role_for(email),
                created_at=datetime.utcnow(),
                last_login_at=datetime.utcnow()
            )
            db.add(u)
        db.commit(); db.refresh(u)
        return u
