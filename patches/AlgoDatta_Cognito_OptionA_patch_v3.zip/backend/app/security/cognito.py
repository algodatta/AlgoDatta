import httpx
from functools import lru_cache
from jose import jwt
from fastapi import HTTPException, status
from app.core.config import settings

ISSUER = settings.oidc_issuer     # https://cognito-idp.<region>.amazonaws.com/<pool_id>
AUD    = settings.oidc_client_id
JWKS   = f"{ISSUER}/.well-known/jwks.json"

@lru_cache(maxsize=1)
def _jwks():
    return httpx.get(JWKS, timeout=5).json()

def verify_access_token(token: str):
    try:
        hdr = jwt.get_unverified_header(token)
        key = next((k for k in _jwks()["keys"] if k["kid"] == hdr["kid"]), None)
        if not key:
            _jwks.cache_clear()
            key = next(k for k in _jwks()["keys"] if k["kid"] == hdr["kid"])
        claims = jwt.decode(token, key, algorithms=["RS256"], audience=AUD, issuer=ISSUER)
        return claims
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
