from fastapi import Depends, HTTPException, status, Request
from app.security.cognito import verify_access_token
from app.db.users_service import upsert_from_claims

def get_current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    claims = verify_access_token(token)
    return upsert_from_claims(sub=claims["sub"], email=claims.get("email"), name=claims.get("name"))
