# Auth Patch — Final Wiring Notes

1) **FastAPI include router**
   Open `backend/app/main.py` (or your FastAPI app factory) and ensure:
   ```py
   from app.api.routers import root_home
   app.include_router(root_home.router)
   ```

2) **CORS (must allow credentials from https://www.algodatta.com)**
   In `main.py`, before include_router calls:
   ```py
   from fastapi.middleware.cors import CORSMiddleware
   app.add_middleware(
       CORSMiddleware,
       allow_origins=["https://www.algodatta.com"],
       allow_credentials=True,
       allow_methods=["*"],
       allow_headers=["*"],
   )
   ```

3) **Environment for role mapping (optional)**
   Set in your backend service environment:
   ```
   DEFAULT_ROLE=trader
   ROLE_EMAIL_MAP={"admin":["admin@yourdomain.com"],"analyst":["analyst@yourdomain.com"],"trader":["trader@yourdomain.com"]}
   ```

4) **API 200 requirement**
   - `GET https://api.algodatta.com/` returns 200 and `{"status":"ok"}` **only when cookies include a valid Cognito access token** and the user role is one of `admin`, `analyst`, `trader`. Anonymous callers will get 401/403 by design.
   - `GET https://api.algodatta.com/healthz` is **public** and returns 200 for uptime checks.
