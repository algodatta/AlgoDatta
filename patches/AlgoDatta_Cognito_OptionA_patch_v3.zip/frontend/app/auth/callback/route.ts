import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const code = sp.get("code");
  const gotState = sp.get("state") || "";
  const jar = cookies();
  const verifier = jar.get("pkce_verifier")?.value || "";
  const savedState = jar.get("oauth_state")?.value || "";

  if (!code || !verifier || gotState !== savedState) return NextResponse.redirect("/auth/error");

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: process.env.OIDC_CLIENT_ID!,
    redirect_uri: process.env.OIDC_REDIRECT_URI!,
    code_verifier: verifier,
    code
  });

  const r = await fetch(`${process.env.COGNITO_DOMAIN}/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  if (!r.ok) return NextResponse.redirect("/auth/error");
  const t = await r.json(); // { access_token, id_token, refresh_token, expires_in }

  const res = NextResponse.redirect("/dashboard", { status: 302 });
  const cookie = { httpOnly:true, secure:true, sameSite:"lax" as const, path:"/", domain: process.env.SESSION_COOKIE_DOMAIN };
  if (t.access_token) res.cookies.set("access_token", t.access_token, { ...cookie, maxAge: 60*12 });
  if (t.id_token)      res.cookies.set("id_token",      t.id_token,      { ...cookie, maxAge: 60*12 });
  if (t.refresh_token) res.cookies.set("refresh_token", t.refresh_token, { ...cookie, maxAge: 60*60*24*30 });
  res.cookies.delete("pkce_verifier"); res.cookies.delete("oauth_state");
  return res;
}
