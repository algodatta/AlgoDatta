import { NextResponse } from "next/server";
import crypto from "crypto";

const b64u = (b: Buffer) => b.toString("base64").replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");

export async function GET() {
  const state = b64u(crypto.randomBytes(16));
  const verifier = b64u(crypto.randomBytes(32));
  const challenge = b64u(crypto.createHash("sha256").update(verifier).digest());

  const url = new URL(`${process.env.COGNITO_DOMAIN}/oauth2/authorize`);
  url.searchParams.set("client_id", process.env.OIDC_CLIENT_ID!);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("redirect_uri", process.env.OIDC_REDIRECT_URI!);
  url.searchParams.set("scope", "openid email profile");
  url.searchParams.set("code_challenge_method", "S256");
  url.searchParams.set("code_challenge", challenge);
  url.searchParams.set("state", state);

  const res = NextResponse.redirect(url.toString(), { status: 302 });
  const cookie = { httpOnly:true, secure:true, sameSite:"lax" as const, path:"/", domain: process.env.SESSION_COOKIE_DOMAIN };
  res.cookies.set("pkce_verifier", verifier, { ...cookie, maxAge: 600 });
  res.cookies.set("oauth_state",   state,    { ...cookie, maxAge: 600 });
  return res;
}
