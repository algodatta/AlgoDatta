export default function LoginPage() {
  return (
    <main className="mx-auto max-w-md p-6">
      <h1 className="text-2xl font-semibold mb-4">Sign in</h1>
      <p className="text-sm text-gray-600 mb-6">Use passkey (recommended), Google, Microsoft, Apple, or email.</p>
      <a href="/auth/login" className="inline-flex items-center rounded-lg px-4 py-2 bg-black text-white">
        Continue
      </a>
    </main>
  );
}
