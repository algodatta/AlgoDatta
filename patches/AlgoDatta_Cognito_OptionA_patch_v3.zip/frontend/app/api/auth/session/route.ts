import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function GET() {
  const id = cookies().get("id_token")?.value;
  if (!id) return NextResponse.json({ authenticated:false });
  try {
    const payload = JSON.parse(Buffer.from(id.split(".")[1] || "", "base64url").toString("utf8"));
    return NextResponse.json({ authenticated:true, email: payload.email, name: payload.name, sub: payload.sub });
  } catch {
    return NextResponse.json({ authenticated:false });
  }
}
