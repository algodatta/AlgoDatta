import { NextResponse } from "next/server";

export async function POST() {
  const cookie = { httpOnly:true, secure:true, sameSite:"lax" as const, path:"/", domain: process.env.SESSION_COOKIE_DOMAIN };
  const res = NextResponse.redirect("/");
  ["access_token","id_token","refresh_token"].forEach(n => res.cookies.set(n,"",{...cookie, maxAge:0}));

  const u = new URL(`${process.env.COGNITO_DOMAIN}/logout`);
  u.searchParams.set("logout_uri", "https://www.algodatta.com/");
  return NextResponse.redirect(u.toString(), { status: 302 });
}
