import { NextRequest, NextResponse } from "next/server";

const PROTECTED = ["/executions", "/strategies", "/reports", "/admin", "/broker", "/dashboard"];

export function middleware(req: NextRequest) {
  if (PROTECTED.some(p => req.nextUrl.pathname.startsWith(p))) {
    const id = req.cookies.get("id_token")?.value;
    if (!id) {
      const url = req.nextUrl.clone();
      url.pathname = "/auth/login";
      return NextResponse.redirect(url);
    }
  }
  return NextResponse.next();
}

export const config = { matcher: ["/((?!_next|api|favicon.ico).*)"] };
