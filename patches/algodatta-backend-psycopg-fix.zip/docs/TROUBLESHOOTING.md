# Backend Postgres Driver Fix

**Problem:** `ModuleNotFoundError: No module named 'psycopg2'`

**Cause:** The Python Postgres driver isn't installed in the backend image.

**Fix (two options):**
1. Apply the git patch:
   ```bash
   cd ~/AlgoDatta
   git apply patches/backend_requirements_psycopg.patch || true
   docker compose -f /etc/algodatta/stack.yml build backend --no-cache
   docker compose -f /etc/algodatta/stack.yml up -d backend
   ```

2. Or run the quick script (appends the dep if missing, then rebuilds):
   ```bash
   unzip algodatta-backend-psycopg-fix.zip -d /tmp/algodatta-psycopg-fix
   bash /tmp/algodatta-psycopg-fix/scripts/quick_fix_psycopg.sh
   ```

**Verify:**
```bash
curl -i http://127.0.0.1:18080/healthz       # or /api/v1/healthz
curl -sS -X POST "https://api.algodatta.com/api/v1/auth/login"   -H "Content-Type: application/json"   -d '{"username":"admin@algodatta.com","password":"Admin@123"}'
```
