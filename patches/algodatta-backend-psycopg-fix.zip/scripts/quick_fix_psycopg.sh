#!/usr/bin/env bash
set -euo pipefail

echo "==> Ensuring psycopg2-binary is in backend/requirements.txt"
cd "${1:-$HOME/AlgoDatta}"

REQ="backend/requirements.txt"
if [ ! -f "$REQ" ]; then
  echo "ERROR: $REQ not found. Run this from the repo root or pass the repo path as first argument."
  exit 1
fi

if grep -qE '^psycopg2-binary(==|>=)' "$REQ"; then
  echo "   psycopg2-binary already present"
else
  echo "psycopg2-binary==2.9.9" >> "$REQ"
  echo "   added psycopg2-binary==2.9.9"
fi

echo "==> Rebuilding backend image (no cache)"
docker compose -f /etc/algodatta/stack.yml build backend --no-cache

echo "==> Restarting backend"
docker compose -f /etc/algodatta/stack.yml up -d backend

echo "==> Waiting briefly then showing last 60 logs"
sleep 4
docker logs algodatta-backend --tail=60 || true

echo "Done."
