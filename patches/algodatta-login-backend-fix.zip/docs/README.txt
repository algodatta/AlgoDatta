# AlgoDatta: Backend Login Fix (Compose + Env + Nginx)

This patch fixes the two root causes that were preventing `/login`:
1) Backend wasn’t starting due to missing `DATABASE_URL`.
2) Port conflicts and incorrect upstream (nginx → :8000 while container couldn’t bind).

## What this installs
- `/etc/algodatta/stack.yml` – single compose bringing up **postgres**, **backend** (bound to `127.0.0.1:18080`) and **frontend**.
- `/etc/algodatta/backend.env` – created from the included sample if not present.
- `/etc/algodatta/api_upstream.conf` – nginx snippet pointing to `127.0.0.1:18080` (you still need to include it in your server block).

## Apply
```bash
unzip algodatta-login-backend-fix.zip -d /tmp/algodatta-fix
cd /tmp/algodatta-fix
bash scripts/apply_stack_fix.sh
```

## Verify
```bash
# on the server
curl -i http://127.0.0.1:18080/healthz   # or /api/v1/healthz

# through nginx (what the browser uses)
curl -i https://api.algodatta.com/api/v1/healthz
```

## Login test
```bash
curl -sS -X POST "https://api.algodatta.com/api/v1/auth/login"   -H "Content-Type: application/json"   -d '{"username":"admin@algodatta.com","password":"Admin@123"}'
```

Then https://www.algodatta.com/login should authenticate and redirect to `/dashboard`.
