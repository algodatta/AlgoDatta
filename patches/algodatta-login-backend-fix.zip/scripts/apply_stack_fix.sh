#!/usr/bin/env bash
set -euo pipefail

# Detect sudo when available
if command -v sudo >/dev/null 2>&1; then
  SUDO="sudo"
else
  SUDO=""
fi

echo "==> Creating /etc/algodatta (if missing)"
$SUDO mkdir -p /etc/algodatta

echo "==> Installing compose stack to /etc/algodatta/stack.yml"
$SUDO cp etc/algodatta/stack.yml /etc/algodatta/stack.yml

if [ ! -f /etc/algodatta/backend.env ]; then
  echo "==> /etc/algodatta/backend.env not found; creating from sample"
  $SUDO cp etc/algodatta/backend.env.sample /etc/algodatta/backend.env
else
  echo "==> Keeping existing /etc/algodatta/backend.env"
fi

echo "==> Copying nginx upstream snippet to /etc/algodatta/api_upstream.conf"
$SUDO cp nginx/api_upstream.snippet /etc/algodatta/api_upstream.conf || true
echo "    NOTE: Update your api.algodatta.com server block to proxy_pass http://127.0.0.1:18080;"

echo "==> Bringing the stack up"
docker compose -f /etc/algodatta/stack.yml up -d --build --remove-orphans

echo "==> Waiting for backend health (up to ~80s)"
ok=""
for i in $(seq 1 40); do
  if curl -fsS http://127.0.0.1:18080/healthz >/dev/null 2>&1; then ok=1; break; fi
  if curl -fsS http://127.0.0.1:18080/api/v1/healthz >/dev/null 2>&1; then ok=1; break; fi
  sleep 2
done

if [ -z "${ok}" ]; then
  echo "!! Backend did not become healthy. Recent logs:"
  docker logs algodatta-backend --tail=200 || true
  exit 1
fi

echo "==> Backend is healthy. If you still see 502 via api.algodatta.com, reload nginx after updating the upstream."
echo "    sudo nginx -t && sudo systemctl reload nginx"

echo "Done."
