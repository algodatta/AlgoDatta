AlgoDatta Backend Quick Fix — psycopg2 driver + rebuild
=======================================================

What this does
--------------
- Ensures `psycopg2-binary==2.9.9` is present in backend/requirements.txt
- Rebuilds the backend image without cache
- Restarts only the backend service from your compose stack
- Waits for health endpoint to respond

Usage
-----
1) Copy the zip to your server and unzip:
   unzip algodatta-psycopg-inline-fix.zip -d /tmp/algodatta-psycopg-inline-fix

2) Run the script (adjust REPO_DIR if your repo lives elsewhere):
   bash /tmp/algodatta-psycopg-inline-fix/scripts/fix_psycopg_and_rebuild.sh
   # or
   STACK_FILE=/etc/algodatta/stack.yml        bash /tmp/algodatta-psycopg-inline-fix/scripts/fix_psycopg_and_rebuild.sh /home/ubuntu/AlgoDatta

3) Verify
   curl -i http://127.0.0.1:18080/healthz || curl -i http://127.0.0.1:8000/healthz
   curl -i https://api.algodatta.com/healthz

If it still fails, check logs
-----------------------------
   docker logs --tail=120 algodatta-backend

Notes
-----
- This script only touches backend/requirements.txt if psycopg2 is missing.
- It respects STACK_FILE if set, otherwise it falls back to /etc/algodatta/stack.yml,
  and finally to your repo's docker-compose.yml plus any available overrides in /etc/algodatta.
