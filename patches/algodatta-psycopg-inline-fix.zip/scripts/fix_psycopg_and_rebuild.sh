#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="${1:-/home/ubuntu/AlgoDatta}"
STACK_FILE_DEFAULT="/etc/algodatta/stack.yml"
STACK_FILE="${STACK_FILE:-$STACK_FILE_DEFAULT}"

echo "==> Repo directory: ${REPO_DIR}"
if [ ! -d "${REPO_DIR}" ]; then
  echo "!! Repository directory not found: ${REPO_DIR}"
  exit 1
fi

REQ_FILE="${REPO_DIR}/backend/requirements.txt"
if [ ! -f "${REQ_FILE}" ]; then
  echo "!! Missing backend requirements file: ${REQ_FILE}"
  exit 2
fi

echo "==> Ensuring psycopg2 driver is present"
if grep -Eiq '^(psycopg2|psycopg2-binary)\b' "${REQ_FILE}"; then
  echo "   - psycopg2 already present"
  ADDED=0
else
  echo "psycopg2-binary==2.9.9" >> "${REQ_FILE}"
  echo "   - Added psycopg2-binary==2.9.9 to ${REQ_FILE}"
  ADDED=1
fi

# Determine docker compose invocation
if [ -f "${STACK_FILE}" ]; then
  COMPOSE="docker compose -f ${STACK_FILE}"
  echo "==> Using stack file: ${STACK_FILE}"
else
  COMPOSE="docker compose -f ${REPO_DIR}/docker-compose.yml"
  [ -f /etc/algodatta/docker-compose.prod.yml ] && COMPOSE="${COMPOSE} -f /etc/algodatta/docker-compose.prod.yml"
  [ -f /etc/algodatta/override-env.yml ] && COMPOSE="${COMPOSE} -f /etc/algodatta/override-env.yml"
  [ -f /etc/algodatta/clear-ports.yml ] && COMPOSE="${COMPOSE} -f /etc/algodatta/clear-ports.yml"
  [ -f /etc/algodatta/ports-hotfix.yml ] && COMPOSE="${COMPOSE} -f /etc/algodatta/ports-hotfix.yml"
  echo "==> Using compose chain: ${COMPOSE}"
fi

echo "==> Building backend image (no cache)"
bash -lc "${COMPOSE} build backend --no-cache"

echo "==> Restarting backend service"
bash -lc "${COMPOSE} up -d backend"

# Health check helper
health() {
  curl -fsS --max-time 2 "http://127.0.0.1:$1/healthz" >/dev/null 2>&1
}

echo "==> Waiting for backend to become healthy at /healthz (tries: 80)"
for i in $(seq 1 80); do
  if health 18080 || health 8000; then
    echo "✓ Backend health is OK"
    exit 0
  fi
  sleep 1
done

echo "!! Backend did not become healthy. Recent logs:"
docker logs --tail=120 algodatta-backend || true
exit 3
