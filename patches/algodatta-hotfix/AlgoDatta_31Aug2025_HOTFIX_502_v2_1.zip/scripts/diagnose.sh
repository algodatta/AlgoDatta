#!/usr/bin/env bash
set -euo pipefail
docker ps --format 'table {{.Names}}	{{.Status}}	{{.Ports}}'
docker ps -a --filter "name=algodatta-backend" --format 'table {{.ID}}	{{.Names}}	{{.Status}}	{{.Ports}}'
ss -ltnp | awk '$4 ~ /:8000$/'
docker compose logs --no-color --tail=200 algodatta-backend || true
docker compose exec -T algodatta-backend sh -lc "ps -ef | grep -i uvicorn | grep -v grep; python - <<'PY'
import urllib.request;print(urllib.request.urlopen('http://127.0.0.1:8000/api/healthz').read())
PY" || true
