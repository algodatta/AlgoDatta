#!/usr/bin/env bash
set -euo pipefail
./scripts/reset_backend.sh
