#!/usr/bin/env bash
set -euo pipefail
docker ps --format 'table {{.Names}}	{{.Status}}	{{.Ports}}'
docker compose logs --no-color --tail=200 algodatta-backend || true
curl -i http://127.0.0.1:8000/api/healthz || true
docker compose exec -T algodatta-backend python - <<'PY' || true
try:
    import email_validator, bcrypt, fastapi, pydantic
    print("imports ok")
except Exception as e:
    print("import error:", e)
PY
