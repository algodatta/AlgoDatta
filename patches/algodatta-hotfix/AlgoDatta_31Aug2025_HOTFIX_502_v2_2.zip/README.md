# HOTFIX v2.2 (adds email-validator + bcrypt pin)
