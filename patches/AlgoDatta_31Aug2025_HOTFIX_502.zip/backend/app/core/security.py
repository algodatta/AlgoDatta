# Placeholder for future security helpers (JWT, scopes, etc.)
