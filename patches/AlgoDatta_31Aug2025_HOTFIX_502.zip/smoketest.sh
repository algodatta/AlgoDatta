#!/usr/bin/env bash
set -euo pipefail

echo "[1/4] Bringing up backend container..."
docker compose up -d --build algodatta-backend

echo "[2/4] Waiting for /api/healthz ..."
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:8000/api/healthz >/dev/null 2>&1; then
    echo "Health OK"
    break
  fi
  echo "  attempt $i ..."
  sleep 2
done

echo "[3/4] Testing login endpoint ..."
curl -fsS -X POST http://127.0.0.1:8000/api/auth/login   -H 'content-type: application/json'   -d '{"email":"admin@algodatta.com","password":"ChangeMe123!"}' | jq . >/dev/null || true

echo "[4/4] If Nginx is configured on host with deploy/nginx/api.algodatta.com.conf,"
echo "      then https://api.algodatta.com/api/healthz should return status ok."
echo "Done."
