# AlgoDatta 31Aug2025 — HOTFIX for 502 on https://api.algodatta.com and login issues

This package provides a minimal, production-safe FastAPI backend and host Nginx config
to eliminate 502s and get `/login` working again.

## TL;DR (on your Lightsail host)

```bash
unzip -o AlgoDatta_31Aug2025_HOTFIX_502.zip -d ~/algodatta-hotfix && cd ~/algodatta-hotfix
cp .env.example .env
export $(grep -v '^#' .env | xargs) || true
docker compose up -d --build

# Verify local health (what Nginx will hit)
curl -sS http://127.0.0.1:8000/api/healthz

# Then drop Nginx conf on HOST (not in docker)
sudo cp deploy/nginx/api.algodatta.com.conf /etc/nginx/sites-available/api.algodatta.com
sudo ln -sf /etc/nginx/sites-available/api.algodatta.com /etc/nginx/sites-enabled/api.algodatta.com
sudo nginx -t && sudo systemctl reload nginx

# Verify public
curl -sS https://api.algodatta.com/api/healthz
```

## Why 502 happened

* The upstream backend process was either **down** or **listening on the wrong interface/port**.
* Nginx pointed to a dead upstream (`proxy_pass`) or timed out before the app responded.
* Root path `/` returned an error, causing health monitors or smoke tests to flag the service.

## What this fixes

* A **minimal FastAPI** app that always responds on `/` and `/api/healthz`.
* Docker publishes backend to **127.0.0.1:8000** so host Nginx can safely proxy.
* A production-ready **Nginx vhost** for `api.algodatta.com`.
* A small **smoketest.sh** to verify container health before switching traffic.

## Notes

* Replace in-memory auth with your DB when ready.
* Ensure `NEXT_PUBLIC_API_BASE=https://api.algodatta.com` in your frontend build.
* CORS allows `https://www.algodatta.com` and `https://algodatta.com` by default here.
```

