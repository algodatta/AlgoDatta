export default function Home(){
  return (<div className="p-6 max-w-6xl mx-auto">
    <h1 className="text-2xl font-bold">AlgoDatta</h1>
    <p className="text-gray-600">Welcome. Use the nav above.</p>
  </div>);
}
