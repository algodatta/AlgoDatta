export default function Home(){
  return (
    <div>
      <h1 className="text-2xl font-bold">AlgoDatta</h1>
      <p className="text-gray-600">Welcome. Use the nav above.</p>
    </div>
  );
}
